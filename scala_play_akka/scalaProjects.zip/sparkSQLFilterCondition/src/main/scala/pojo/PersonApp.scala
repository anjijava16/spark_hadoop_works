package com.scala.pojo

object PersonApp {
  def main(args: Array[String]): Unit = {

    var personObj = new Person("anji", "mm", 27);
    
    println(personObj.toString);
    
    
  }
}
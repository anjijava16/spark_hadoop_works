package com.iwinner.spark.test.scala

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

object ScalaWordCountSimple {
  def main(args: Array[String]) {
    val spark = new SparkContext(args(0), "Scala WordCount")
    val file = spark.textFile(args(1))
    val counts = file.flatMap(line => line.split(" ")).map(word => (word, 1)).reduceByKey(_ + _)
    counts.saveAsTextFile(args(2))
  }
}

package com.iwinner.spark.sparkcore

object Test {
  def main(args: Array[String]): Unit = {
    
    
    print("Test");
    
  }
  
}
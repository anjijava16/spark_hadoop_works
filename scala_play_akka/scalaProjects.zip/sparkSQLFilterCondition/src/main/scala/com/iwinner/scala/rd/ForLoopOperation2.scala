package com.iwinner.scala.rd



object ForLoopOperation2 {
  def main(args: Array[String]): Unit = {
    
    var a=0;

    for(a<- 1 until 10){
      println("a  value is "+a);
    }
    
    
    /*
    for( a <- 1 to 10){
         println( "Value of a: " + a );
      }
*/  }
}
package com.iwinner.scala.rd

object Employee {
  var name:String=_
  var age:Int=_
  var male:Boolean=_
  
  
  
}
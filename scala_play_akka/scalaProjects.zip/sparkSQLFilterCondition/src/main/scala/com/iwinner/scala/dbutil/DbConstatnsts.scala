package com.iwinner.scala.dbutil

trait DbConstatnsts {

  var URL = "jdbc:mysql://localhost/wsdb"
  var USERNAME = "root";
  var PASSWORD = "root"
  var DRIVER = "com.mysql.jdbc.Driver"
  
  val DRIVER_NAME = "com.mysql.jdbc.Driver"

}
package com.iwinner.spark.test.scala

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

object ScalaWordCountSaveOutput {
  def main(args: Array[String]) {
    // Check the app args
    if (args.length < 3) {
      System.err.println("Usage: WordCount <master> <input file> <>output file>")
      System.exit(1)
    }

    // Get app args
    val master = args(0)
    val inputFile = args(1)
    val outputFile = args(2)

    // Create spark context
    // Create spark context
    val spark = new SparkContext(master, "WordCount")

    // Load file string lines into RDD
    val file = spark.textFile(inputFile)

    // Map to split lines and get single words
    val mapFile = file.flatMap(line => line.split(" "))

    // Map to create word and "1" tuples
    val mapper = mapFile.map(word => (word, 1))

    // Reduce to calculate word counts
    val reducer = mapper.reduceByKey(_ + _)

    // Save counts output into file
    reducer.saveAsTextFile(outputFile)

    // Close Java Spark Context to shutdown
    spark.stop()

    System.exit(0)
  }
}

package com.iwinner.spark.test.scala

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

object ScalaWordCount {
  def main(args: Array[String]) {
    if (args.length < 2) {
      System.err.println("Usage: WordCount <master> <file>")
      System.exit(1)
    }

    // Get app args
    val master = args(0)
    val inputFile = args(1)

    // Create spark context
    val spark = new SparkContext(master, "WordCount")

    // Load file string lines into RDD
    val file = spark.textFile(inputFile)

    // Map to split lines and get single words
    val mapFile = file.flatMap(line => line.split(" "))

    // Map to create word and "1" tuples
    val mapper = mapFile.map(word => (word, 1))

    // Reduce to calculate word counts
    val reducer = mapper.reduceByKey(_ + _)

    // Display word counts
    for (count <- reducer) {
      println(count)
    }

    // Close Java Spark Context to shutdown
    spark.stop()

    System.exit(0)
  }
}

package com.iwinner.spark.test.scala

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd.RDD

object ScalaWordCountDemo2 {
  def main(args: Array[String]) {
    if (args.length < 2) {
      System.err.println("Usage: WordCount <master> <file>")
      System.exit(1)
    }

    // Get app args
    val master = args(0)
    val inputFile = args(1)

    // Create spark context
    val spark = new SparkContext(master, "Scala WordCount")

    //    printSep()
    //    println(spark.getConf.toDebugString)

    // Load file string lines into RDD
    val file = spark.textFile(inputFile)
    file.setName("file_rdd")

    //    printSep()
    //    println(file.toDebugString)
    //    println("number of partitions: " + file.partitions.length)

    // Perform repartition
    //    file.repartition(4)
    //
    //    printSep()
    //    println("after repartition: " + file.toDebugString)
    //    println("number of partitions after repartition: " + file.partitions.length)

    // Print number of lines
    //    file.cache()
    //    println("number of lines: " + file.count())
    //
    //    printSep()
    //    println("after repartition and count: " + file.toDebugString)
    //    println("number of partitions after repartition and count: " + file.partitions.length)

    // Map to split lines and get single words
    val mapFile = file.flatMap(line => line.split(" "))

    //    printSep()
    //    println(mapFile.toDebugString)

    // Map to create word and "1" tuples
    val mapper = mapFile.map(word => (word, 1))

    //    printSep()
    //    println(mapper.toDebugString)

    // Reduce to calculate word counts
    val reducer = mapper.reduceByKey(_ + _)
    reducer.setName("reducer_rdd")

    //    printSep()
    //    println(reducer.toDebugString)

    // Cache reducer output
    //    reducer.cache();
    //
    //    printSep()
    //    println(reducer.toDebugString)

    // Print number of counts
    //    println("number of counts: " + reducer.count())
    //
    //    printSep()
    //    println(reducer.toDebugString)

    // Print number of counts
    //    println("number of counts(again): " + reducer.count())

    // Display word counts
    for (count <- reducer) {
      println(count)
    }

    // Close Java Spark Context to shutdown
    spark.stop()

    System.exit(0)
  }

  def printSep() {
    println("--------------------------------------------------------------------------------")
  }
}

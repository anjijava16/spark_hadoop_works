spark-submit \
   --class com.test.test.Main \
   lib/spark-demo-1.0.0.jar \
   default
